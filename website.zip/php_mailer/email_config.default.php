<?php
define('EMAIL_USER','<YOUR EMAIL>');
define("EMAIL_USERNAME", "<YOUR USERNAME>");
define('EMAIL_PASS','<YOUR PASSWORD>');
?>