<?php
define('EMAIL_USER','nickquan.dev@gmail.com');
define('EMAIL_USERNAME', 'Nick Quan');
define('EMAIL_PASS','CroutonEmilyLakers');
?>